<template>
  <div>
    <img class="block" :src="empty" />
  </div>
</template>

<script setup lang="ts">
import empty from "../assets/empty.png";
</script>

<style scoped></style>
