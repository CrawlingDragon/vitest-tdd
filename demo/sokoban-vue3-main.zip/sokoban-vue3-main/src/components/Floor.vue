<template>
  <div>
    <img class="block" :src="floor" />
  </div>
</template>

<script setup lang="ts">
import floor from "../assets/floor.png";
</script>

<style scoped></style>
