<template>
  <div>
    <img class="block" :src="wall" />
  </div>
</template>

<script setup lang="ts">
import wall from "../assets/wall.png";
</script>

<style scoped></style>
