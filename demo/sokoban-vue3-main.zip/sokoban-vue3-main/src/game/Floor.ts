export class Floor {
  public name: string = "Floor";
}
