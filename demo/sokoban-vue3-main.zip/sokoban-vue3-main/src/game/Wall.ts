export class Wall {
  public name: string = "Wall";
}
