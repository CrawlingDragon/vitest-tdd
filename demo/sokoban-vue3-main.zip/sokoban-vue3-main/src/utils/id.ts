let id = 0;

export function generateId() {
  return id++;
}
